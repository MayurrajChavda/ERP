<?php
    $host = "localhost";
    $user = "root";
    $password = "";
    $conn = mysqli_connect($host,$user,$password) or die ("could not connect to mysql");
?>